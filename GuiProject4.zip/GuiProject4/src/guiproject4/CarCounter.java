/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guiproject4;

/**
 *
 * @author User
 */
public class CarCounter {
    private static int counter = 0;
    
    public static void increaseCounter(){
        counter += 1;
    }
    
    public static int getCounter(){
        return counter;
    }
}
