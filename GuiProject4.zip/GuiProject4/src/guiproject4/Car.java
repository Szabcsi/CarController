/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guiproject4;

import javax.swing.JLabel;

/**
 *
 * @author User
 */
public class Car {
    private String name;
    private String threadId;
    private JLabel carLabel;
    private int xPos;
    private int yPos;
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getThreadId() {
        return threadId;
    }

    public void setThreadId(String threadId) {
        this.threadId = threadId;
    }

    public JLabel getCarLabel() {
        return carLabel;
    }

    public void setCarLabel(JLabel carLabel) {
        this.carLabel = carLabel;
    }

    public int getXPos() {
        return xPos;
    }

    public void setXPos(int xPos) {
        this.xPos = xPos;
    }

    public int getYPos() {
        return yPos;
    }

    public void setYPos(int yPos) {
        this.yPos = yPos;
    }
    
    
}
