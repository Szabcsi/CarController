/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guiproject4;

import java.awt.Color;
import java.util.HashMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author User
 */
public class CarControllerApplication extends JFrame {
 JButton jButtonAddCar,jButtonDown,jButtonUp,jButtonLeft,jButtonRight;
    JPanel jPanel;
    JComboBox<String> jComboBx;
    HashMap<String,Car> carHashMap; 
    
    public CarControllerApplication(){
        jButtonAddCar = new JButton("Add Car");
        jButtonDown = new JButton("Down");
        jButtonUp = new JButton("Up");
        jButtonLeft = new JButton("Left");
        jButtonRight = new JButton("Right");
        jComboBx = new JComboBox<String>();
        jPanel = new JPanel();
        setLayout(null);
        jButtonAddCar.setBounds(10, 10, 80 ,30);
        jButtonAddCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddCarActionPerformed(evt);
            }
        });
        jButtonDown.setBounds(90, 10, 70 ,30);
        jButtonDown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDownActionPerformed(evt);
            }
        });
        jButtonUp.setBounds(160, 10, 70, 30);
        jButtonUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUpActionPerformed(evt);
            }
        });
        jButtonLeft.setBounds(230, 10, 70 ,30);
        jButtonLeft.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLeftActionPerformed(evt);
            }
        });
        jButtonRight.setBounds(300, 10, 70 ,30);
        jButtonRight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRightActionPerformed(evt);
            }
        });
        jComboBx.setBounds(130, 40, 120, 30);
        
        
        jPanel.setBounds(30, 70, 320, 320);
        jPanel.setOpaque(true);
        jPanel.setBackground(Color.CYAN);
        
        carHashMap = new HashMap<String,Car>();
        
        add(jButtonAddCar);
        add(jButtonDown);
        add(jButtonUp);
        add(jButtonLeft);
        add(jButtonRight);
        add(jComboBx);
        add(jPanel);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       CarControllerApplication app = new CarControllerApplication();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setTitle("Controlling cars");
        app.setSize(400, 450);
        app.setVisible(true); 
    }
    
     private void jButtonAddCarActionPerformed(java.awt.event.ActionEvent evt) {                                         
        CarCounter.increaseCounter();
        String carName = "Car" + CarCounter.getCounter();
        Car car = new Car();
        car.setName(carName);
        JLabel carLabel = new JLabel(carName);
        carLabel.setLocation(100, 80);
        car.setXPos(100);
        car.setYPos(80);
        car.setCarLabel(carLabel);
        carHashMap.put(carName, car);
        jComboBx.addItem(carName);
        setLayout(null);
        jPanel.add(carLabel);
        System.out.println("x: " + carLabel.getAlignmentX() +"  y: "+ carLabel.getAlignmentY());
        System.out.println("x: " + carLabel.getX()+"  y: "+ carLabel.getY());
        
        /*jPanel.validate();
        jPanel.repaint();*/
    }                                        

    private void jButtonDownActionPerformed(java.awt.event.ActionEvent evt) {                                         
        JLabel carLabel = null;
        if(CarCounter.getCounter()>0){
            String carName = (String)jComboBx.getSelectedItem();
            Car car = carHashMap.get(carName);
            car.setYPos(car.getYPos() + 1);
            carLabel = car.getCarLabel();
            carLabel.setLocation(car.getXPos(), car.getYPos());
        }
        
        System.out.println("x: " + carLabel.getX()+"  y: "+ carLabel.getY());
    }                                        
    
    private void jButtonUpActionPerformed(java.awt.event.ActionEvent evt) {                                         
        JLabel carLabel = null;
        if(CarCounter.getCounter()>0){
            String carName = (String)jComboBx.getSelectedItem();
            Car car = carHashMap.get(carName);
            car.setYPos(car.getYPos() - 1);
            carLabel = car.getCarLabel();
            carLabel.setLocation(car.getXPos(), car.getYPos());
        }
        System.out.println("x: " + carLabel.getX()+"  y: "+ carLabel.getY());
    }                                        
    
    private void jButtonLeftActionPerformed(java.awt.event.ActionEvent evt) {                                         
        JLabel carLabel = null;
        if(CarCounter.getCounter()>0){
            String carName = (String)jComboBx.getSelectedItem();
            Car car = carHashMap.get(carName);
            car.setXPos(car.getXPos() - 1);
            carLabel = car.getCarLabel();
            carLabel.setLocation(car.getXPos(), car.getYPos());
        }
        System.out.println("x: " + carLabel.getX()+"  y: "+ carLabel.getY());
    }                                        
    
    private void jButtonRightActionPerformed(java.awt.event.ActionEvent evt) {                                         
        JLabel carLabel = null;
        if(CarCounter.getCounter()>0){
            String carName = (String)jComboBx.getSelectedItem();
            Car car = carHashMap.get(carName);
            car.setXPos(car.getXPos() + 1);
            carLabel = car.getCarLabel();
            carLabel.setLocation(car.getXPos(), car.getYPos());
        }
        System.out.println("x: " + carLabel.getX()+"  y: "+ carLabel.getY());
    }                                        
    
}
